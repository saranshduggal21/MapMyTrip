//Going to create a basic Express application - Going to create one existing ROUTE (one, single route).
//Then make sure that our express server listens to some port on our local machine, and we will then use the test route to make sure that some content can appear.

require("./models/userSchema"); //This line can only be used once. To import userSchema into other files, check the "userAuthenticationRoutes" file. 
const express = require("express"); //Importing the Express library.
const mongoose = require("mongoose"); //Importing the Mongoose library.
const userAuthenticationRoutes = require("./routes/userAuthenticationRoutes");


const app = express(); //Creating an app object, which represents our entire application, and we can assosciate some different route handlers with it.

app.use(express.json()); //BodyParser is a helper library that will automatically parse JSON data associated with the body property of incoming requests. 
//bodyParser will parse some JSON data out of the incoming requests, and once it parses that info, it's going to associate all of that info on the body property of the "req" object in "userAuthenticationRoutes".
//Since I have Express 4.16.0+, body parser has been deprecated and re-added to the "express.json()" methods, to provide request body parsing support out-of-the-box.

app.use(userAuthenticationRoutes); //Associates all the request handlers (that were added to the router in "userAuthenticationRoutes") with the MAIN EXPRESS APPLICATION as our "app" object.

const mongoDBConnection = "mongodb+srv://user1:password123.@cluster0.h7e7d.mongodb.net/MapyMyTrip?retryWrites=true&w=majority" //mongoDBConnection = Connection string given by MongoDB.
//mongoDBConnection can then be used to connect to our mongoDB instance using Mongoose.
mongoose.connect(mongoDBConnection);

mongoose.connection.on("connected", () => {
    //Making sure that we succesfully conenct to Mongo instance and that errors can be detectde as the connection occurs.
    console.log("Successfully connected to MongoDB instance.");
});

mongoose.connection.on("error", (e) => { //The callback function as 2nd argument will be called with some "error" object.
    console.error("There was an error connecting to MongDB instance.", e);
});

app.get ("/", (req, res) => { //Setting up 1st route handler and setting a function as the 2nd argument.
    //Anytime, we make a "get" type HTTP request to the root route of our application, the following function will run.
    //The function gets called automatically, with a request object (object that represents the incoming HTTP request), and a "res" object (represents the outgoing response). 
    res.send("Hello!");
});

app.listen(3000, () => { //App object will listen to a certain port on our local machine, in which a callback function is being passed as the 2nd argument. 
    console.log("Listening to port 3000");
});