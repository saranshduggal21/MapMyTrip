//This file will be used for defining the user schema and creating the User Model with Mongoose so that we can manipulate all the different users we have stored in MongoDB's User Collection. 
const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({ //Using the mongoose object, we can create the IDEA of a User Model. 
    //The Schema object is where we tell Mongoose about the different properties that every user inside of the User Collection (Mongo) is going to have.

    email: { //User will always have an email, so "email" is a property that's going to be assigned an object to configure some information about 
        type: String,
        unique: true, //By adding the configuration tag of "unique", Mongoose is going to modify MongoDB's collection of users and it's goign to tell MongoDB that every user must have a unique email. 
            //So, if anyone tries to save 2 users with duplicate emails, we're going to get an error message. 
        required: true //Anhtime wee try to save a new user to our Users Collection in MongoDB, if the user doesn't have an email, then they're invalid and shouldn't be allowed to save them.
    },
    password: {
        type: String,
        required: true
    }
});

mongoose.model("newUser", userSchema); //Associating the user schema with mongoose library, which tells Mongoose about the kind of structure and data that every user must have. 