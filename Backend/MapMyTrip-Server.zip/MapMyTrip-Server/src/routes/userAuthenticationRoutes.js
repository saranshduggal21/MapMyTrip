//This file will consist of all of the "request handling" logic to deal with anything related to authentication (i.e. signing up, signing in, etc.).

const express = require("express");
const mongoose = require("mongoose");
const User = mongoose.model("newUser");
const jwt = require("jsonwebtoken");

const router = express.Router();
//ROUTER: An object that allows us to associate some number of route handlers with it. The "router" can be associated back with the "app" object that was created in "index.js".

router.post("/Signup", async (req, res) => {
    //Anytime someone makes a post request to sign up, the following callback function will run with the "req" & "res" objects.

    const { email, password } = req.body; //The "req.body" property is an object that has an EMAIL & PASSWORD property, which is why it can be destructured off to create the new user.

    try {
        const user = new User({ email, password });
        await user.save(); //"save()" is an ASYNCHRONOUS operation because, MongoDB has to reach out over the Internat to the hosted instanace of MongoDB (in "index.js"), and initiate the "save()" operation. 
       
        const userToken = jwt.sign( {userMongoID: user._id}, "KOBE248"); //The first argument in the "sign" function is the information we want to put inside of the JWT (payload).
        //The 2nd argument is the "key" that is going to be used to sign the JWT. This key is supposed to be very secret info that shouldn't be shared with the outside world, otherwise anybody can create a JWT, with any arbitrary user ID. 

        res.send({JWT: userToken});
    } 
    catch (error) { //Catching any error (i.e. lack of password, not a unique email, etc.) that is thrown during the process of saving the user to the MongoDB User Collections.
        //Sending error back to the user.

        return res.status(422).send(error.message)
        //"422" indicates that the user entered some invalid data when creating a new account. 
        //Since we don't know what the error is, "error.message" is what's going to be produced by Mongoose automatically, to send back to the user. 
    }
});

//In order to make sure that the "router" can be used by our application, the following line is mandatory. Then, "router" must be IMPORTED in "index.js".
module.exports = router;
