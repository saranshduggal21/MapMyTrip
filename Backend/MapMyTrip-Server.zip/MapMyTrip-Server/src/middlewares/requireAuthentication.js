//Below is a MIDDLEWARE function: A function that has access to the request ("req"), response ("res") objects, and the "next" function in the application's request-response cycle. 

const JWT = require("jsonwebtoken");
const mongoose = require("mongoose");
const User = mongoose.model("newUser");

module.exports = (req, res, next) => { //Defining and exporting a middleware function to determine that a user does have a valid JWT, and then AUTHORIZE THE USER. 
    //If JWT is invalid, then the request will be rejected and an error will be sent to the user.
    //Anytime this middleware runs, "req" will be inspected in order to look for a header called "Authorization", and if its them, then the JWT will be extracted from it and be validated. 

    const {authorization} = req.headers;
    //So authorization == "Bearer (*insert JWT*)"
    if (!authorization) {
        //If user didn't provide an authorization header, then this isn't a valid request. 
        return res.status(401).send({error: "You aren't logged in!"});
    }

    const extractToken = authorization.replace("Bearer ", "")
    
    //In order to validate the extracted token, the following line of code must be added:
    JWT.verify(extractToken, "KOBE248", async (error, payload) => {
        //1st argument = extracted token || 2nd argument = 256-Bit Secret Key || 3rd argument = callback function that's invoked after JWT has been verified.
        //The callback function is called with "error" if there's an error while verifying the JWT, and "payload" is the info that was encoded within the JWT. 

        if (error) {
            return res.status(401).send({error: "Invalid JSON Web Token!"});
        }

        const {userMongoID} = payload;
        const newUser = await User.findById(userMongoID); //Going to tell Mongoose that to search through the MongoDB collection, and attempt to find a user with the given "userMongoID".
        //After locating the user, it's going to assign that user to the "newUser" variable. 
    }); 
}